<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Consolidado financiero <?php echo e($year); ?></title>
</head>
<body>
    <h1>Consolidado financiero - Año <?php echo e($year); ?></h1>

    <p>Total cuentas: <?php echo e($cuentas->count()); ?></p>

    <table border="1" cellpadding="4" cellspacing="0">
        <thead>
            <tr>
                <th>Estudiante</th>
                <th>Total deuda</th>
                <th>Total pagado</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cuenta->student->nombres); ?> <?php echo e($cuenta->student->apellidos); ?></td>
                <td><?php echo e($cuenta->total_debt); ?></td>
                <td><?php echo e($cuenta->total_paid); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\User\Videos\practicasbolibia\colegio-api\resources\views/finance/consolidado.blade.php ENDPATH**/ ?>
<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Assignment;

class AssignmentPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole([
            'SuperAdmin',
            'Director General',
            'Director Académico',
            'Docente',
        ]);
    }

    public function view(User $user, Assignment $assignment): bool
    {
        if ($user->hasRole('Docente')) {
            return $user->teacher_id === $assignment->teacher_id;
        }

        return $user->hasAnyRole([
            'SuperAdmin',
            'Director General',
            'Director Académico',
        ]);
    }

    public function create(User $user): bool
    {
        return $user->hasAnyRole([
            'SuperAdmin',
            'Director General',
            'Director Académico',
        ]);
    }

    public function update(User $user, Assignment $assignment): bool
    {
        return $this->create($user);
    }

    public function delete(User $user, Assignment $assignment): bool
    {
        return $this->create($user);
    }
}
